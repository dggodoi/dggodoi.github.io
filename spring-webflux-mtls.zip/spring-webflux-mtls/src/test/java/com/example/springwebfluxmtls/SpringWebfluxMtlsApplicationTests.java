package com.example.springwebfluxmtls;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebfluxMtlsApplicationTests {

	@Test
	void contextLoads() {
	}

}
