package com.example.springwebfluxmtls.controller;

import com.example.springwebfluxmtls.client.MtlsClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("hello")
public class HelloController {

    private final MtlsClient mtlsClient;

    public HelloController(MtlsClient mtlsClient) {
        this.mtlsClient = mtlsClient;
    }

    @RequestMapping("ping")
    public String ping() {
        return "PONG!";
    }

    @RequestMapping("mtls")
    public ResponseEntity<Mono<String>> mtls() {
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(mtlsClient.getMessage());
    }

}
